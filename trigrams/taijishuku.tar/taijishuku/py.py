import re
from lxml import etree,html
import os
import json

ls=filter(lambda s:s.startswith('clean'),os.listdir())

j=json.load(open('../trigramsN.json','r'))
for f in ls:
    with open(f,'r',encoding='utf8') as iof:
        t=iof.read()

    h=etree.fromstring(t,parser=html.HTMLParser(remove_blank_text=True))

    p_tag_list = h.xpath('//*')
    for p_tag in h:
        etree.strip_tags(p_tag, 'tt')

    n=h.xpath('//div[@id="chapter"]')+h.xpath('//img')#+h.xpath('//sup')
    for cn in n:
        cn.getparent().remove(cn)


    for n in h.xpath('//*[@*]'):
        ats=n.attrib
        if not ats:
            continue
        for a in ats:
            n.attrib.pop(a)

    while n:=h.xpath("//*[not(node())]"):
        for cn in n:
            cn.getparent().remove(cn)

    s=etree.tostring(h,encoding='utf-8',pretty_print=True).decode('utf8')
    # print(s)

    with open('new_'+f,'w') as iof:
        iof.write(s)

    # if "卦十八" in h.xpath("/html/body/p")[0].text:
        # print(etree.tostring(h,encoding='utf-8',pretty_print=True).decode('utf8'))
    order=int(f.split('.')[0].split('_')[-1])
    para=[i.text for i in h.xpath("/html/body/p")]
    yaos=[i.text for i in h.xpath('/html/body/div[2]/p')]

    name,desc=re.sub('[-—]+','-',para[0]).split('-')
    name:str=name[:name.find('(')].strip()

    triexpl=para[1]
    yaoexpl=para[2:8]

    yaos=list(zip(yaos,yaoexpl))
    yaos.reverse()

    allexpl=para[8:]

    for k,v in j.items():
        if order==v['order'] and name == v['name']:
            d={'desc':desc,'trigram_explain':triexpl,'yaos':yaos,'explain':allexpl}
            d.update(v)
            j[k]=d
            break
    else:
        print('no found: '+str(order)+name)


json.dump(j,open('trigram.json','w'),ensure_ascii=False,indent=2)
