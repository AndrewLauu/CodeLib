from lxml import etree,html
import os
import json

j=json.load(open('../trigramsN.json','r'))
ls=list(filter(lambda i:i.endswith('.html'),os.listdir()))
burl='https://www.guoyi360.com'
for f in ls:
    with open(f,'r') as iof:
        t=iof.read()
    h=etree.fromstring(t,parser=html.HTMLParser(remove_blank_text=True))
    desc=h.xpath('/html/body//div[@class="pddh-list64gua"]/p')[0].text.strip()
    for k,v in j.items():
        if int(f.split('.')[0])==v['order']:
            d={'desc2':desc}
            d.update(v)
            j[k]=d
            break

json.dump(j,open('../trigram.json','w'),indent=2,ensure_ascii=False)
